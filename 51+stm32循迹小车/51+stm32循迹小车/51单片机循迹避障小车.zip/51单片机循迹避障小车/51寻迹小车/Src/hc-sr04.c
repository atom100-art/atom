
#include "hc-sr04.h"

u16 EchoCnt;

void HC04_Init(void)
{
	Trig = 0;
	Echo = 0;
	TMOD &=0Xf0;
	TMOD |=0X01;//定时器模式选择
	TH0=0;//定时器高低八位配置初值
	TL0=0;
	EA=1;//总中断开关
	TR0=0;//定时器0开关
	ET0=1;//定时器0中断允许开关
	
}

void HC04_Loop(void)
{  
	Trig = 1;
	DelayUs(20);
	Trig = 0;		//	发送Trig信号
	
	while(Echo == 0);		//	超声波发送信号标志位
	TH0=0;	
	TL0=0;			//	清除定时器高、低八位
	TR0=1;			//	打开定时器开始计数
	while(Echo == 1);		// 超声波接受到返回信号标志位
	EchoCnt = (TH0*256 + TL0)*1.7/100;	//	公式计算距离
	TR0=0;		//	关闭定时器
}

