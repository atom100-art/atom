
#include "dcmotor.h"

/*
控制小车电机运动的函数
*/
void MotorContorl(MOTOR_DIR dir, u8 speed)
{
	switch(dir)
	{
		// 直走
		case FORWARD:
			MOTOR0 = 0;
			MOTOR1 = 1;
			MOTOR2 = 0;
			MOTOR3 = 1;
		break;
		// 后退
		case BACKUP:
			MOTOR0 = 1;
			MOTOR1 = 0;
			MOTOR2 = 1;
			MOTOR3 = 0;
		break;
		// 左转
		case LEFT:
			MOTOR0 = 1;
			MOTOR1 = 0;
			MOTOR2 = 0;
			MOTOR3 = 1;
		break;
		// 右转
		case RIGHT:
			MOTOR0 = 0;
			MOTOR1 = 1;
			MOTOR2 = 1;
			MOTOR3 = 0;
		break;
		//	停止ֹ
		case STOP:
			MOTOR0 = 1;
			MOTOR1 = 1;
			MOTOR2 = 1;
			MOTOR3 = 1;
		break;
		// 停止ֹ
		default:
			MOTOR0 = 1;
			MOTOR1 = 1;
			MOTOR2 = 1;
			MOTOR3 = 1;
		break;
	}
	DelayMs(speed);		// speed��ֵԽ���ٶ�Խ��
	MOTOR0 = 1;
	MOTOR1 = 1;
	MOTOR2 = 1;
	MOTOR3 = 1;
	DelayMs(25 - speed);	// speed��ֵԽ����ʱʱ��Խ�̣��ٶ�Խ��
}
