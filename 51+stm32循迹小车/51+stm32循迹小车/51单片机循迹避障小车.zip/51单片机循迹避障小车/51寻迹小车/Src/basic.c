
#include "basic.h"
/*
	延时us函数
*/
void DelayUs(u16 i)
{
	while(--i);
}
/*
延时ms函数
*/
void DelayMs(u16 t)
{
	u16 i,j;
	for(i=0; i<t; i++)
		for(j=0; j<120; j++);
}
