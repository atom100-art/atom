#include "basic.h"		//所有的头文件

void main(void)				// 主函数
{
	UartInit();
	HC04_Init();
	SendString("SystemInitial\r\n");
	while(1)
	{
		HC04_Loop();   //循环检测距离
		if(EchoCnt < 15)			// 判断是否有障碍物
				{
		
						MotorContorl(LEFT, 25);		
		
				}
				else
				{
						if((GO_RIGHT == 1) && (GO_LEFT == 0))			// 标志位
							{
								MotorContorl(RIGHT, 23);				// 右转
							}
							else if((GO_RIGHT == 0) && (GO_LEFT == 1))		// 标志位
							{
								MotorContorl(LEFT, 23);				// 左转
							}
							else if((GO_RIGHT == 0) && (GO_LEFT == 0))		// 标志位
							{
								MotorContorl(FORWARD, 23);			// 直走
							}
				}
	}
}
