#include "stm32f10x.h"
#include "SysTick.h"
#include "system.h"

void TIM2_PWM_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;  
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);  
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_0; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	TIM_TimeBaseStructure.TIM_Period = 199; 
	TIM_TimeBaseStructure.TIM_Prescaler =7199; 
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure); 

	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low; 
	
	TIM_OC1Init(TIM2, &TIM_OCInitStructure); 
	TIM_OC2Init(TIM2, &TIM_OCInitStructure); 
	TIM_OC3Init(TIM2, &TIM_OCInitStructure); 
	TIM_OC4Init(TIM2, &TIM_OCInitStructure);  
	
	TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable); 
	TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable); 
	TIM_OC3PreloadConfig(TIM2, TIM_OCPreload_Enable); 
	TIM_OC4PreloadConfig(TIM2, TIM_OCPreload_Enable); 

	TIM_Cmd(TIM2, ENABLE);  	

}

void go()
{
	TIM_SetCompare1(TIM2,0); 	
	TIM_SetCompare2(TIM2,37); 
	TIM_SetCompare3(TIM2,0);
	TIM_SetCompare4(TIM2,37); 
}

void left()
{
	TIM_SetCompare1(TIM2,0); 	
	TIM_SetCompare2(TIM2,31); 
	TIM_SetCompare3(TIM2,0);
	TIM_SetCompare4(TIM2,36); 
}

void right()
{
	TIM_SetCompare1(TIM2,0); 	
	TIM_SetCompare2(TIM2,36); 
	TIM_SetCompare3(TIM2,0);
	TIM_SetCompare4(TIM2,31); 
}

void bigleft()
{
	TIM_SetCompare1(TIM2,0); 	
	TIM_SetCompare2(TIM2,30); 
	TIM_SetCompare3(TIM2,0);
	TIM_SetCompare4(TIM2,45); 
}

void bigright()
{
	TIM_SetCompare1(TIM2,0); 	
	TIM_SetCompare2(TIM2,45); 
	TIM_SetCompare3(TIM2,0);
	TIM_SetCompare4(TIM2,30); 
}

void maxleft()
{
	TIM_SetCompare1(TIM2,0); 	
	TIM_SetCompare2(TIM2,100); 
	TIM_SetCompare3(TIM2,0);
	TIM_SetCompare4(TIM2,50); 
}

void maxright()
{
	TIM_SetCompare1(TIM2,0); 	
	TIM_SetCompare2(TIM2,50); 
	TIM_SetCompare3(TIM2,0);
	TIM_SetCompare4(TIM2,100); 
}

void GPIOB_Init()	
{
  GPIO_InitTypeDef GPIO_InitStructure;	
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE); 
	
  GPIO_InitStructure.GPIO_Pin =GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8;	
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
}

#define L1 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)
#define L2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)
#define R2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)
#define R1 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)

void delay(u32 i)
{
	while(i--);
}

int main()
{
	SysTick_Init(72);
	GPIOB_Init();
	TIM2_PWM_Init();
	GPIO_SetBits(GPIOA,GPIO_Pin_7|GPIO_Pin_9);
	GPIO_ResetBits(GPIOA,GPIO_Pin_8|GPIO_Pin_10);
	while(1)
	{

		if(L1==0&&L2==1&&R2==1&&R1==0)
	  {
	  go();		
	  delay_ms(10);
	  }
		else if(L1==0&&L2==1&&R2==0&&R1==0)
	  {
	  right();
	  delay_ms(10);
	  }
		else if(L1==0&&L2==0&&R2==1&&R1==0)
	  {
	  left();	
	  delay_ms(10);
	  }
		else if(L1==0&&L2==0&&R2==1&&R1==1)
	  {
	  bigleft();	
	  delay_ms(10);
	  }
		else if(L1==1&&L2==1&&R2==0&&R1==0)
	  {
	  bigright();	
	  delay_ms(10);
	  }
		else if(L1==0&&L2==0&&R2==0&&R1==1)
	  {
	  bigleft();	
	  delay_ms(10);
	  }
		else if(L1==1&&L2==0&&R2==0&&R1==0)
	  {
	  bigright();	
	  delay_ms(10);
	  }
		  
	}
}

