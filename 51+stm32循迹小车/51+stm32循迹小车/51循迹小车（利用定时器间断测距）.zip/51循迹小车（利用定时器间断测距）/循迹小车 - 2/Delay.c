#include <INTRINS.H>

void Delay10us(unsigned int xus)		//@11.0592MHz
{
	while(xus)
	{
		unsigned char i;

		_nop_();
		i = 25;
		while (--i);
		xus--;
	}
}
