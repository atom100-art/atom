#include <REGX52.H>
#include "Timer0.h"
#include "Delay.h"
#include "ultrwave.h"

/*
循迹工作原理：
通过检测红外信号判断轨迹，通过左右电机的差速转动转向

红外检测模块：
有检测到信号时（白色）P2输出0，且亮灯；
无检测到信号时（黑色）P2输出1，且灭灯；

右边的红外探测器对应P2_0口,右边电机OUT3、OUT4接IN3、IN4接P1_0、P1_1
左边的红外探测器对应P2_1口,左边电机OUT1、OUT2接IN1、IN2接P0_0、P0_1

ENA、ENB是PWM控速信号接口
IN1、IN3是电机的输电接口

ENA、ENB为使能端，控制电机差速转动；
IN1(IN3)=0,IN2(IN4)=1时，电机正转；
IN1(IN3)=1,IN2(IN4)=0时，电机反转；

超声波测距模块：
Trig为控制端，用于发出触发信号；
Echo为输出端，用于判断是否有障碍物且测量障碍物的距离。
当测试的距离<3cm时小车电机停止转动

Timer0为定时器1
ultrwave里的计时器为计时器0
*/

unsigned int Counter_L,Compare_L,Counter_R,Compare_R;
unsigned int i=0;
int t;

sbit LED1 = P3^0;  //红外线模块正常输出检测
sbit LED2 = P3^1;

sbit Moter_R=P1^0;  //电机使能端引脚定义
sbit Moter_L=P1^1;

sbit IN1=P1^7;   //右电机正反转定义
sbit IN2=P1^6;
sbit IN3=P1^5;   //左电机正反转定义
sbit IN4=P1^4;

sbit HWSM_L=P2^1;  //红外线探测模块的引脚定义
sbit HWSM_R=P2^2;

sbit Trig=P3^5;  //超声波模块引脚定义
sbit Echo=P3^6;

void main()
{
	int dist;
	Timer1Init();//计时器1初始化
//	ultrwave_init();//超声波函数（计时器0）初始化
	Compare_L=14;Compare_R=14;  //电机配速
	
	while(1)
	{
		
		if(t == 100)
		{
			dist = ultrwave_meas();//超声波测距 
		}
		
		if(dist<10 && dist>0)
		{IN1=0;IN2=0;IN3=0;IN4=0;LED1=0;LED2=0;}  //如果检测到障碍物则停止前进
//		else{LED1=1;LED2=1;}
		else if(HWSM_R==0 && HWSM_L==0)
		{IN1=0;IN2=1;IN3=0;IN4=1;}  //未检测到线，全速直行
		else if(HWSM_R==1 && HWSM_L==0)
		{IN1=1;IN2=0;IN3=0;IN4=1;}		   		//如果右边的传感器检测到黑线，则右轮减速左轮加速且检测灯亮起
		else if(HWSM_L==1 && HWSM_R==0)
		{IN1=0;IN2=1;IN3=1;IN4=0;}		//如果左边的传感器检测到黑线，则左轮减速右轮加速且检测灯亮起
		else
		{IN1=0;IN2=1;IN3=0;IN4=1;}  //同时检测到黑线则保持直行
	}
}

void Timer1_Routine() interrupt 3
{
//	static unsigned int T0Count;
	t++;
	if(t == 100)
	{t=0;}
	TL1 = 0xA4;		//设置定时初值
	TH1 = 0xFF;		//设置定时初值
	Counter_L++;
	Counter_R++;
	Counter_L %= 100;//每隔10毫秒为一个周期控制电机转速
	Counter_R %= 100;
	if(Counter_L<Compare_L)	//PWM左电机配速
	{
		Moter_L=1;
	}
	else
	{
		Moter_L=0;
	}
		
	if(Counter_R<Compare_R)	//PWM右电机配速
	{
		Moter_R=1;
	}
	else
	{
		Moter_R=0;
	}
}