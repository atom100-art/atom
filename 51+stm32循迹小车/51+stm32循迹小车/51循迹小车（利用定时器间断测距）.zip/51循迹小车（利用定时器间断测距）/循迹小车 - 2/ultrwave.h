#ifndef __ULTRWAVE_H__
#define __ULTRWAVE_H__

//#include <reg52.h>
#include "Delay.h"
//#include "buzzer.h"

void ultrwave_init();
unsigned int ultrwave_meas(void);

#endif