#include <REGX52.H>
#include "Motordirver.h"

//L298n�߼����ܿ�
sbit IN1=P0^6;
sbit IN2=P0^5;
sbit IN3=P0^4;
sbit IN4=P0^3;

void RightMotoForward()
{IN3=0; IN4=1;}
void RightMotoBack()
{IN3=1; IN4=0;}
void LeftMotoBack()
{IN1=0; IN2=1;}
void LeftMotoForward()
{IN1=1; IN2=0;}
void RightMotoStop()
{IN3=1; IN4=1;}
void LeftMotoStop()
{IN1=1; IN2=1;}
